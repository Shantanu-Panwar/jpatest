package com.cognizant.truyum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TruyumSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(TruyumSpringApplication.class, args);
	}

}
