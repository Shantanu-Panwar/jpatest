package com.cognizant.truyum.repository;

import org.springframework.data.repository.CrudRepository;

import com.cognizant.truyum.model.MenuItem;

public interface MenuItemRepository extends CrudRepository<MenuItem , Integer> {

}
